var shell = new ActiveXObject("WScript.Shell");

while (true) {
  shell.Run("notepad.exe");
  WScript.Sleep(1000); // 1 Sekunde warten
}
